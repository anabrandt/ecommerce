import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ComprasOnlineApp extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Compras Online");

        // Simulando a lista de produtos
        ObservableList<String> produtos = FXCollections.observableArrayList(
                "Celular", "Laptop", "Roupas", "Livros", "Fones de ouvido"
        );

        // Ordenando a lista por nome
        produtos.sort(String::compareToIgnoreCase);

        ListView<String> listaProdutos = new ListView<>(produtos);

        VBox root = new VBox(listaProdutos);
        Scene scene = new Scene(root, 300, 200);

        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}



@FXML TextField txtNome;
    @FXML TextField txtSetor;
    @FXML TextArea txtAlunos;

    // String[] nomes; //array primitivo

    // collection
    ArrayList<String> nomes = new ArrayList<>();

    public void adicionar(){
        String nome = txtNome.getText() + txtSetor.getText();    // pegar o nome do aluno no textfiel
        //txtAlunos.appendText(nome + "\n");// adicionar o nome do textarea
        nomes.add(nome);                    //substituiu o anterior


        //anonymous class
            //é uma classe que nao precisa de fato criar;
            //usado apenas em casos especificos;
            //funçao anonima - arrow function - expressao lambda
        nomes.sort(( o1, o2)->o1.compareToIgnoreCase(o2));


        mostrarAlunos();
    }

    public void mostrarAlunos(){
        txtAlunos.clear();
        //para cada nome na lista de nomesa
        for(String nome : nomes){
            //add o nome no txtAre
            txtAlunos.appendText(nome + "\n");
        }
    }
}