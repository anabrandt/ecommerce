package com.example;

import java.util.ArrayList;

import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
// import javafx.scene.image.ImageView;
//alt shift o = organiza os itens e importa eles aqui em cima criando uma importacao
public class PrimaryController {
    // @FXML ImageView imgView;
    @FXML TextField txtNome;
    @FXML TextArea txtAlunos;
//criar varios valores numa variavel, array list= serve para criar listas.
    //colections server para ultilizar os arrays lists
    ArrayList<String> nomes = new ArrayList<>();
    // armazena qualquer coisa 

    //adicionar o nome na lista
    public void adicionar(){
        //o get serve para pegar o atributo na caixa de texto
        String nome = txtNome.getText();
        nomes.add(nome);
        //o metodo sort ordena os itens dentro de uma array
        nomes.sort(( o1, o2)->o1.compareToIgnoreCase(o2));
        //essa classe nao precisa ser publica porque ela ja existe dentro do arquivo adicionar 
        //esse comparador coloca os alunos de forma alfabetica
            //  @Override  //estrategia de comparacao 
            //     public int compare 
        mostrarAlunos();
    }

    public void mostrarAlunos(){
        txtAlunos.clear();
        //para cada nome na lista de nomesa
        for(String nome : nomes){
            //add o nome no txtAre
            txtAlunos.appendText(nome + "\n");


        }
    }
    


}
